"""
src/api/main.py  –  FastAPI application factory.

IMPORTANT: load_dotenv() is called FIRST so LangSmith picks up env vars correctly.
"""
from __future__ import annotations

# ── Load .env into os.environ BEFORE any langsmith/langchain imports ──────────
import os
from dotenv import load_dotenv
load_dotenv()

import sys
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger

from src.api.routes import router
from src.config import get_settings

_settings = get_settings()

# ─── Logging ──────────────────────────────────────────────────────────────────
logger.remove()
logger.add(sys.stderr,
           format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | {message}",
           level="INFO")
os.makedirs("logs", exist_ok=True)
logger.add("logs/asa.log", rotation="10 MB", retention="7 days", level="DEBUG")


# ─── App ──────────────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    app = FastAPI(
        title="Agentic Support Assistant (ASA)",
        description=(
            "Production-grade agentic RAG — hybrid search, smart query expansion, "
            "TinyBERT reranking, semantic cache, SSE streaming."
        ),
        version="2.0.0",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=_settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(router, prefix="/api/v1", tags=["ASA"])

    @app.get("/")
    async def root():
        return {"name": "ASA", "version": "2.0.0", "docs": "/docs", "health": "/api/v1/health"}

    @app.on_event("startup")
    async def startup():
        logger.info("ASA startup – pre-loading models…")
        from src.ingestion.embedder import get_dense_model
        from src.retrieval.reranker import get_reranker
        get_dense_model()
        get_reranker()
        logger.success("Models loaded. ASA is ready.")

    return app


app = create_app()

if __name__ == "__main__":
    uvicorn.run("src.api.main:app", host=_settings.api_host, port=_settings.api_port,
                workers=1, reload=False, log_level="info")
